%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                    This algorithm is for the paper:                     %
%    "hydroSIM: Super-resolution speckle illumination microscopy with a   %
%                             hydrogel diffuser"                          %
%            Please cite our paper on Biomedical Optics Express           %
%-------------------------------------------------------------------------%
%    This algorithm is written based on L.-H. Yeh et al work with major   %
%             modification, please also cite their work:                  %
%       "Structured illumination microscopy with unknown patterns and a   %
%            statistical prior," Biomed. Opt. Express 8695-711 (2017)     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [data_projection_dec,I_obj_corrected] = INT_DEC(Ip_est,I_PR,reg_shading,dec_itr_cov_rec,Final_PSF,dec_reg_rec)

% F = @(x) fftshift(fft2(ifftshift(x)));
% iF = @(x) fftshift(ifft2(ifftshift(x)));

[N,M,~] = size(Ip_est);


data_projection_dec = deconvlucy(I_PR,Final_PSF,dec_itr_cov_rec,dec_reg_rec);
data_projection_dec(data_projection_dec<0) = 0;



I_p_mean   = mean(Ip_est,3);

shading_factor = mean((Ip_est-I_p_mean).^2,3);

shading_reg     = reg_shading*max(shading_factor(:)).^2;

I_obj_corrected = data_projection_dec.*shading_factor./(shading_factor.^2+shading_reg);

end




















