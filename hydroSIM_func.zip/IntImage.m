%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                    This algorithm is for the paper:                     %
%    "hydroSIM: Super-resolution speckle illumination microscopy with a   %
%                             hydrogel diffuser"                          %
%            Please cite our paper on Biomedical Optics Express           %
%-------------------------------------------------------------------------%
%    This algorithm is written based on L.-H. Yeh et al work with major   %
%             modification, please also cite their work:                  %
%       "Structured illumination microscopy with unknown patterns and a   %
%            statistical prior," Biomed. Opt. Express 8695-711 (2017)     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [data_projection,I_PR] = IntImage(Ip_est,I_image_up,range_ps)

Ip_est     = gpuArray(Ip_est);
I_image_up = gpuArray(I_image_up);
range_ps   = gpuArray(range_ps);

tic


[N,M,Nimg] = size(I_image_up);



Nsx = range_ps;
Nsy = range_ps;

Ns = Nsx*Nsy;
pixel_step = 2;

sx = (-(Nsx-1)/2:(Nsx-1)/2).*pixel_step;
sy = (-(Nsy-1)/2:(Nsy-1)/2).*pixel_step;

[syy,sxx] = meshgrid(sy,sx);


s_stack = zeros(2,Ns);
s_stack(1,:) = syy(:);
s_stack(2,:) = sxx(:);


I_p_mean = mean(Ip_est    ,3);
I_mean   = mean(I_image_up,3);

data_projection = gpuArray.zeros(N,M,Nsy,Nsx);
I_PR            = gpuArray.zeros(N,M);

for i = 1:Ns
    [x,y] = ind2sub([Nsx,Nsy],i);
    for j = 1:Nimg
        data_projection(:,:,y,x) = data_projection(:,:,y,x) + circshift((Ip_est(:,:,j)-I_p_mean),[s_stack(1,i)   , s_stack(2,i)]).*(I_image_up(:,:,j)-I_mean);
    end
        I_PR                     = I_PR                     + circshift(data_projection(:,:,y,x),[-s_stack(1,i)/2,-s_stack(2,i)/2]);
end



toc
end







