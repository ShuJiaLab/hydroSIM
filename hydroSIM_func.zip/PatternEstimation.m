%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                    This algorithm is for the paper:                     %
%    "hydroSIM: Super-resolution speckle illumination microscopy with a   %
%                             hydrogel diffuser"                          %
%            Please cite our paper on Biomedical Optics Express           %
%-------------------------------------------------------------------------%
%    This algorithm is written based on L.-H. Yeh et al work with major   %
%             modification, please also cite their work:                  %
%       "Structured illumination microscopy with unknown patterns and a   %
%            statistical prior," Biomed. Opt. Express 8695-711 (2017)     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function [Ip_est,I_mean,I_mean_dec] = PatternEstimation(I_image_up,T_incoherent,max_itr,reg_delta,I_mean_dec_t)

    I_image_up   = gpuArray(I_image_up);
    T_incoherent = gpuArray(T_incoherent);
    reg_delta    = gpuArray(reg_delta);
    
    
    F  = @(x) fftshift(fft2(ifftshift(x)));
    iF = @(x) fftshift(ifft2(ifftshift(x)));
    
    [N,M,Nimg] = size(I_image_up);
    
    
    I_mean     = mean(I_image_up,3);

    I_mean_dec = I_mean_dec_t; % deconvlucy(I_mean,Mean_PSF,dec_itr_mean,dec_reg_mean);
    I_mean_dec(I_mean_dec<0) = 0;
    I_mean_dec = I_mean_dec/max(I_mean_dec(:));
    

    T_incoherent_wn = T_incoherent.^2./(T_incoherent.^2+reg_delta);
    I_mean_dec_Duo  = 2*I_mean_dec;

    Ip_est   = gpuArray(zeros(N,M,Nimg));
    Ip_est_t = gpuArray(zeros(N,M));

    tic;
    fprintf('| Pattern #  |  error ratio  | Elapsed time (sec) |\n');
    for i = 1:Nimg
            Ip_est_i = Ip_est_t;

            forward = iF(T_incoherent.*F(Ip_est_i.*I_mean_dec));
            
            err_initial_i = I_image_up(:,:,i) - forward;

            % Ip_est(:,:,i) = Ip_est(:,:,i) + I_mean_dec_Duo.*iF(T_incoherent.*F(err_initial_i))/max(I_mean_dec(:))^2 ; % Gaussian gradient
            Ip_est_i = Ip_est_i + I_mean_dec_Duo.*iF(T_incoherent.*F(err_initial_i)) ; % Gaussian gradient
            Ip_est_i = iF(F(Ip_est_i).*T_incoherent_wn );

            Ip_est_i(Ip_est_i<0) = 0;
            tempp = Ip_est_i;       
            t = 1;
           
        for j = 2:max_itr
            forward = iF(T_incoherent.*F(Ip_est_i.*I_mean_dec));
            % Ip_est(:,:,i) = Ip_est(:,:,i) + I_mean_dec_Duo.*iF(T_incoherent.*F(I_image_up(:,:,i) - forward))/max(I_mean_dec(:))^2 ; % Gaussian gradient
            Ip_est_i = Ip_est_i + I_mean_dec_Duo.*iF(T_incoherent.*F(I_image_up(:,:,i) - forward)) ; % Gaussian gradient
            Ip_est_i = iF(F(Ip_est_i).*T_incoherent_wn );

            Ip_est_i(Ip_est_i<0) = 0;
            temp = Ip_est_i;
    
            tp = t;
            t = (1+sqrt(1+4*tp^2))/2;
            Ip_est_i = temp + (tp-1)*(temp - tempp)/t;
            tempp = temp;
        end

        Ip_est(:,:,i) = Ip_est_i;

        forward = iF(T_incoherent.*F(Ip_est(:,:,i).*I_mean_dec));

        err_initial = sum(abs(err_initial_i)              .^2,'all');
        err_final   = sum(abs(I_image_up(:,:,i) - forward).^2,'all');

        fprintf('|    %2d      |     %.2f  %%   |        %.2f        |\n', i, err_final/err_initial*100,toc);
    end

    Ip_est     = gather(abs(Ip_est));
    I_mean     = gather(I_mean);
    I_mean_dec = gather(I_mean_dec);

end













